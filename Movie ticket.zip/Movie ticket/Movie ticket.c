#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<windows.h>


int normal();
int gold();
int platinum();
int movie_data();
int transection();

struct book
{
	char code[20];
	char name[20];
	char date[20];
	char time[20];

}b;

int seat = 60 ;

void insert_details();
void viewAll();
void find();
void book_ticket();
void old_record();
void edit();

void main()
{

	 int ch;
 	do{
	printf("\n====================================================================");
	printf("\n");
	printf("\t               Moive Ticket booking ");
	printf("\n");
	printf("\n====================================================================");

	printf("\nPress <1> Insert Movie");
   	printf("\nPress <2> Find Movie");
	printf("\nPress <3> view all movie ");
	printf("\nPress <4> Book Ticket");
	printf("\nPress <5> View All Transections");
	printf("\nPress <6> Edit");
   	printf("\nPress <0> Exit ");

   	printf("\nEnter your Choice ::");
   	scanf("%d",&ch);

   	switch (ch)
   	{
    		case 1 :
    		insert_details();
   		break;
		case 2:
    		find();
   		break;

		case 3:
    		viewAll();
   		break;

		case 4:
		book_ticket();
		break;

		case 5:
		old_record();
		break;
		case 6:
			edit();
			break;

    		case 0:
    		exit(0);
    		break;

    		default:
    		printf("Wrong choice !");
    		break;
   	}
 }while(ch!=0);




}


void insert_details()
{

	FILE *fp;
	struct book b;
	printf("\n\tEnter movie code :- ");
	scanf("%s",b.code);
	printf("\n\tEnter  name :- ");
	scanf("%s",b.name);
	printf("\n\tEnter Release Date:- ");
	scanf("%s",b.date);

{
    SYSTEMTIME stime;
     GetSystemTime(&stime);
     printf("\n\t\t\t\tDate--Time--Year: ");
     printf("%d--%d--%d",stime.wDay,stime.wMonth,stime.wYear);

}
	fp=fopen("data.txt","a");

	if(fp == NULL)
	{
		printf("FIle not Found");
	}
	else
	{
		fprintf(fp,"\n\t\tCode:%s\n\t\tName:%s\n\t\tDate:%s\n",b.code,b.name,b.date);
		printf("Record insert Sucessfull");
	}
		printf("\n");
	fclose(fp);
}
void find()
{
	struct book b;
    system("cls");
    FILE *fp;
    char movie_code[30];
    printf("\n\n\n\n\t\t\t\tEnter movie code: ");
	scanf("%s",movie_code);

	fp = fopen("data.txt","r");
	if(fp == NULL)
	{
		printf("file does not found !");
		exit(1);

	}
	else
	{
			while(fscanf(fp," Code:%s\nName:%s\nDate:%s\n",b.code,b.name,b.date) != EOF)
		{




			if(strcmp(b.code,movie_code) == 0)
			{
                 printf("\n\t\t\t\t\t***********");
				 printf("\n\t\t\t\t\tmovie found\n");
                 printf("\t\t\t\t\t***********");
				 printf("\n\n\t\t\t\tmovie code: ");
                 printf("%s",b.code);

                 printf("\n\t\t\t\tMovie Name: ");
                 printf("%s",b.name);

                 printf("\n\t\t\t\tRelease date: ");
                 printf("%s",b.date);




			}
        }
    }fclose(fp);

}
void viewAll()
{
	char ch;
	FILE *fp;

	fp = fopen("data.txt","r");
	if(fp == NULL)
	{
		printf("file does not found !");
		exit(1);

	}
	else
	{
		system("cls");
		while( ( ch = fgetc(fp) ) != EOF )
      		printf("%c",ch);

	}
	fclose(fp);
}

void book_ticket()
{
 struct book b;
 int typechoice;



	char ch;
	char movie_code[20];
	FILE *fp;




	fp = fopen("data.txt","r");
	if(fp == NULL)
	{
		printf("file does not found !");
		exit(1);

	}
	else
	{
		system("cls");
		while( ( ch = fgetc(fp) ) != EOF )
      		printf("%c",ch);

	}
	fclose(fp);


	printf("\n For Book ticket Choise Movie :\n");

	printf("\n Enter movie code :");
	scanf("%s",movie_code);

	fp = fopen("data.txt","r");
	if(fp == NULL)
	{
		printf("file does not found !");
		exit(1);

	}
	else
	{
		while(fscanf(fp," Code:%s\nName:%s\nDate:%s\n",b.code,b.name,b.date) != EOF)
		{

			if(strcmp(b.code,movie_code) == 0)
			{

				printf("\n Record Found\n");
				printf("\n\t\tCode ::%s",b.code);
				printf("\n\t\tMovie name ::%s",b.name);
				printf("\n\t\tdate name ::%s",b.date);

			}
		}

	}
	printf("\n\n\n\t\t\t\t\t=============================\n");
            printf("\t\t\t\t\t\tTicket Type\n");
            printf("\t\t\t\t\t=============================\n\n");

            printf("\t\t\t\t\t\t1.  Normal  =150 Taka \n");
            printf("\t\t\t\t\t\t2.  Gold    =250 Taka\n");
            printf("\t\t\t\t\t\t3.  Platinum=400 Taka\n\n\n");

            printf("\t\t\t\t\t\tENTER YOUR CHOICE: ");

            scanf("%d",&typechoice);

            switch(typechoice)
            {
            case 1:
                normal();
                break;
            case 2:
                gold();
                break;
            case 3:
                platinum();
                break;
            }

	}

int normal()
{
	system("cls");
    FILE *fp;
    struct book b;
    int ch,choice;
    int total_seat,mobile,total_amount,time;
	char name[20];


    fp = fopen("Transection.txt","a");

   printf("\n* Fill Deatails  *");
	printf("\n your name :");
	scanf("%s",name);
	printf("\n mobile number :");
	scanf("%d",&mobile);
	printf("\n Total number of tickets :");
	scanf("%d",&total_seat);
	printf("\n time :1.Morning[11:30Am] 2.Noon[2:30pm] 3.Evening[5:30pm] 4.[8:30pm]\n");
	printf("\nSelect time:");
	scanf("%d",&time);

    total_amount = 150 * total_seat;


    printf("\n\n\t\t\t\t\tTHE TOTAL CHARGE IS: ");
    printf("%d",total_amount);

        fprintf(fp,"\n\t\tName:%s",name);
		fprintf(fp,"\n\t\tMobile Number:%d",mobile);
		fprintf(fp,"\n\t\tTotal Seat:%d",total_seat);

		fprintf(fp,"\n\t\tTotal Amount:%d",total_amount);
		fprintf(fp,"\n\t\tTime:%d",time);
		printf("\n Record insert Sucessfull to the old record file");
	{
		printf("\n");
	}
	fclose(fp);
  fp=fopen("tranjection_temp.txt","w+");
   fprintf(fp,"\n\t\tName:%s",name);
		fprintf(fp,"\n\t\tMobile Number:%d",mobile);
		fprintf(fp,"\n\t\tTotal Seat:%d",total_seat);

		fprintf(fp,"\n\t\tTotal Amount:%d",total_amount);
		fprintf(fp,"\n\t\tTime:%d",time);
		fclose(fp);


	printf("\n\n\t\tshow Ticket::\n\t\t");
	printf("\n\n\t\t\t\tClick 1: ");
    scanf("%d",&choice);
    if(choice==1)
    {
        system("cls");

        fp=fopen("tranjection_temp.txt","r+");

        fscanf(fp,"%s",name);
        fscanf(fp,"%d",&mobile);
        fscanf(fp,"%d",&total_seat);
        fscanf(fp,"%d",&total_amount);
        fscanf(fp,"%d",&time);


    	printf("\n ENJOY MOVIE \n");
	printf("\n\t\tname : %s",name);
	printf("\n\t\tmobile Number : %d",mobile);
	printf("\n\t\tTotal seats : %d",total_seat);
	printf("\n\t\tcost per ticket::400 Taka");
	printf("\n\t\tTotal Amount : %d",total_amount);
	printf("\n\t\tShow time:%d",time);
	printf("\n\t\t\t\t\t\t time :1.Morning[11:30Am] 2.Noon[2:30pm]\n\n");
	printf("\n\t\t\t\t\t\t time :3.Evening[5:30pm]  4.Night[8:30pm] \n");
	

	fclose(fp);
}
	else
	{
		printf("FIle not Found");
	}



}


int gold()
{
	system("cls");
    FILE *fp;
    struct book b;
    int ch,choice;
    int total_seat,mobile,total_amount,time;
	char name[20];


    fp = fopen("Transection.txt","a");

   printf("\n* Fill Deatails  *");
	printf("\n your name :");
	scanf("%s",name);
	printf("\n mobile number :");
	scanf("%d",&mobile);
	printf("\n Total number of tickets :");
	scanf("%d",&total_seat);
	printf("\n time :1.Morning[11:30Am] 2.Noon[2:30pm] 3.Evening[5:30pm] 4.Night[8:30pm]\n");
	printf("\nSelect time:");
	scanf("%d",&time);

    total_amount = 250 * total_seat;


    printf("\n\n\t\t\t\t\tTHE TOTAL CHARGE IS: ");
    printf("%d",total_amount);

        fprintf(fp,"\n\t\tName:%s",name);
		fprintf(fp,"\n\t\tMobile Number:%d",mobile);
		fprintf(fp,"\n\t\tTotal Seat:%d",total_seat);

		fprintf(fp,"\n\t\tTotal Amount:%d",total_amount);
		fprintf(fp,"\n\t\tTime:%d",time);
		printf("\n Record insert Sucessfull to the old record file");
	{
		printf("\n");
	}
	fclose(fp);
  fp=fopen("tranjection_temp.txt","w+");
   fprintf(fp,"\n\t\tName:%s",name);
		fprintf(fp,"\n\t\tMobile Number:%d",mobile);
		fprintf(fp,"\n\t\tTotal Seat:%d",total_seat);

		fprintf(fp,"\n\t\tTotal Amount:%d",total_amount);
		fprintf(fp,"\n\t\tTime:%d",time);
		fclose(fp);


	printf("\n\n\t\tshow Ticket::\n\t\t");
	printf("\n\n\t\t\t\tClick 1 to print your ticket: ");
    scanf("%d",&choice);
    if(choice==1)
    {
        system("cls");

        fp=fopen("tranjection_temp.txt","r+");

        fscanf(fp,"%s",name);
        fscanf(fp,"%d",&mobile);
        fscanf(fp,"%d",&total_seat);
        fscanf(fp,"%d",&total_amount);
        fscanf(fp,"%d",&time);


    	printf("\n ENJOY MOVIE \n");
	printf("\n\t\tname : %s",name);
	printf("\n\t\tmobile Number : %d",mobile);
	printf("\n\t\tTotal seats : %d",total_seat);
	printf("\n\t\tcost per ticket::400 Taka");
	printf("\n\t\tTotal Amount : %d",total_amount);
	printf("\n\t\tShow time:%d",time);
	printf("\n\t\t\t\t\t\t time :1.Morning[11:30Am] 2.Noon[2:30pm]\n\n");
	printf("\n\t\t\t\t\t\t time :3.Evening[5:30pm]  4.Night[8:30pm] \n");
	

	fclose(fp);
}
	else
	{
		printf("FIle not Found");
	}



}


int platinum()
{
	system("cls");
    FILE *fp;
    struct book b;
    int ch,choice;
    int total_seat,mobile,total_amount,time;
	char name[20];


    fp = fopen("Transection.txt","a");

   printf("\n* Fill Deatails  *");
	printf("\n your name :");
	scanf("%s",name);
	printf("\n mobile number :");
	scanf("%d",&mobile);
	printf("\n Total number of tickets :");
	scanf("%d",&total_seat);
	printf("\n time :1.Morning[11:30Am] 2.Noon[2:30pm] 3.Evening[5:30pm] 4.Night[8:30pm]\n");
	printf("\nSelect time:");
	scanf("%d",&time);

    total_amount = 400 * total_seat;


    printf("\n\n\t\t\t\t\tTHE TOTAL CHARGE IS: ");
    printf("%d",total_amount);

        fprintf(fp,"\n\t\tName:%s",name);
		fprintf(fp,"\n\t\tMobile Number:%d",mobile);
		fprintf(fp,"\n\t\tTotal Seat:%d",total_seat);

		fprintf(fp,"\n\t\tTotal Amount:%d",total_amount);
		fprintf(fp,"\n\t\tTime:%d",time);
		printf("\n Record insert Sucessfull to the old record file");
	{
		printf("\n");
	}
	fclose(fp);
  fp=fopen("tranjection_temp.txt","w+");
   fprintf(fp,"\n\t\tName:%s",name);
		fprintf(fp,"\n\t\tMobile Number:%d",mobile);
		fprintf(fp,"\n\t\tTotal Seat:%d",total_seat);

		fprintf(fp,"\n\t\tTotal Amount:%d",total_amount);
		fprintf(fp,"\n\t\tTime:%d",time);
		fclose(fp);


	printf("\n\n\t\tshow Ticket::\n");
	printf("\n\n\t\t\t\tClick 1 to print your Ticket: ");
    scanf("%d",&choice);
    if(choice==1)
    {
        system("cls");

        fp=fopen("tranjection_temp.txt","r+");

        fscanf(fp,"%s",name);
        fscanf(fp,"%d",&mobile);
        fscanf(fp,"%d",&total_seat);
        fscanf(fp,"%d",&total_amount);
        fscanf(fp,"%d",&time);


    	printf("\n ENJOY MOVIE \n");
	printf("\n\t\tname : %s",name);
	printf("\n\t\tmobile Number : %d",mobile);
	printf("\n\t\tTotal seats : %d",total_seat);
	printf("\n\t\tcost per ticket::400 Taka");
	printf("\n\t\tTotal Amount : %d",total_amount);
	printf("\n\t\tShow time:%d",time);
	printf("\n\t\t\t\t\t\t time :1.Morning[11:30Am] 2.Noon[2:30pm]\n\n");
	printf("\n\t\t\t\t\t\t time :3.Evening[5:30pm]  4.Night[8:30pm] \n");
	

	fclose(fp);
}
	else
	{
		printf("FIle not Found");
	}



}




void old_record()
{
	char ch;
	FILE *fp;



	fp = fopen("Transection.txt","r");
	if(fp == NULL)
	{
		printf("file does not found !");
		exit(1);

	}
	else
	{
		system("cls");
		while( ( ch = fgetc(fp) ) != EOF )
      		printf("%c",ch);

	}
	fclose(fp);


}
void edit()
{
	int ch;

	printf("\n\t\t\t1.Movie Data\n");
	printf("\n\t\t\t2.Transection\n");

printf("\nEnter your Choice ::");
   	scanf("%d",&ch);


   	switch (ch)
   	{
    		case 1 :
    		movie_data();
   		break;
		case 2:
    		transection();
   		break;
    	}
    }

    	int movie_data()
	{
	system("data.txt");
                system("pause");
            }

            int transection()
			{

            system("transection.txt");
            system("pause");
        }



